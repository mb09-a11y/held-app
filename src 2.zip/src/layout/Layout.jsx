// src/layout/Layout.jsx
// Bottom nav + side nav for the RCC shell.
//
// V2 changes:
//   - ChildPill added to BottomNav top bar area (mobile)
//   - ChildSwitcher removed from SideNav — child switching lives in AppDrawer
//   - RCC earth palette via T tokens
//   - Cormorant Garamond for brand mark

import { useT, useApp, font, serif } from "../core/shared.jsx";
import { ThemeToggle } from "../core/shared.jsx";
import { ChildPill } from "../views/shared/AppDrawer.jsx";

const SUBSTACK_URL = "https://substack.com/@manu142886/notes?utm_campaign=profile&utm_medium=profile-page";

// ─── BOTTOM NAV ───────────────────────────────────────────────────────────────
export function BottomNav({ tabs, active, setActive, unread, onOpenDrawer }) {
  const T = useT();
  const { currentUser } = useApp();
  const isParent = currentUser?.role === "parent" || currentUser?.role === "co_caregiver";

  return (
    <div className="rcc-bottom-nav" style={{
      position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 100,
      borderTop: `1px solid ${T.border}`,
      background: T.bg,
      padding: "0 0 env(safe-area-inset-bottom, 16px)",
    }}>
      {/* Child pill strip — sits above the tab row on mobile */}
      {isParent && onOpenDrawer && (
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "6px 16px 0",
          borderBottom: `1px solid ${T.border}`,
        }}>
          <ChildPill onOpen={onOpenDrawer} />
          {/* Hamburger / menu button on right */}
          <button onClick={onOpenDrawer} style={{
            background: "none", border: "none", cursor: "pointer",
            color: T.muted, fontSize: 18, padding: "2px 4px", lineHeight: 1,
          }}>
            ☰
          </button>
        </div>
      )}

      {/* Tab buttons */}
      <div style={{ display: "flex" }}>
        {tabs.map(t => {
          const badge = unread?.[t.id];
          const isActive = active === t.id;
          return (
            <button key={t.id} onClick={() => setActive(t.id)} style={{
              flex: 1, minWidth: 0, background: "none", border: "none",
              display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
              padding: "8px 0",
              cursor: "pointer", position: "relative",
              color: isActive ? T.teal : T.muted,
              fontFamily: font, fontSize: 10,
              fontWeight: isActive ? 700 : 400,
              transition: "color .2s",
              overflow: "hidden",
            }}>
              <span style={{ fontSize: 20 }}>{t.icon}</span>
              <span style={{
                whiteSpace: "nowrap", overflow: "hidden",
                textOverflow: "ellipsis", width: "100%", textAlign: "center",
              }}>
                {t.label}
              </span>
              {/* Active indicator dot */}
              {isActive && (
                <span style={{
                  position: "absolute", bottom: 2,
                  width: 4, height: 4, borderRadius: "50%",
                  background: T.teal,
                }} />
              )}
              {badge > 0 && (
                <div style={{
                  position: "absolute", top: 4, right: "50%",
                  transform: "translateX(10px)",
                  width: 16, height: 16, borderRadius: "50%",
                  background: T.rose,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 9, fontWeight: 700, color: "#fff",
                }}>
                  {badge}
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── SIDE NAV ─────────────────────────────────────────────────────────────────
// Desktop sidebar. Child switching removed — lives in AppDrawer only.
export function SideNav({
  tabs, active, setActive, onLogout,
  onOpenNotifications, onOpenAccount, onOpenFindConsultant,
  currentUser, T,
  onOpenDrawer, // opens AppDrawer for child switching
}) {
  const { families, activeChild } = useApp();
  const isParent = currentUser?.role === "parent" || currentUser?.role === "co_caregiver";
  const hasConsultant = families?.[0]?.consultant_id;

  function SideRow({ icon, label, onClick }) {
    return (
      <button onClick={onClick} style={{
        display: "flex", alignItems: "center", gap: 10,
        width: "100%", padding: "10px 20px",
        background: "none", border: "none",
        borderLeft: "3px solid transparent",
        fontFamily: font, fontSize: 13, color: T.muted,
        cursor: "pointer", textAlign: "left",
        transition: "color .15s",
      }}
        onMouseEnter={e => e.currentTarget.style.color = T.text}
        onMouseLeave={e => e.currentTarget.style.color = T.muted}
      >
        <span style={{ fontSize: 15, width: 20, textAlign: "center" }}>{icon}</span>
        {label}
      </button>
    );
  }

  return (
    <div className="rcc-sidebar">
      {/* Brand mark */}
      <div style={{ padding: "24px 20px 20px", borderBottom: `1px solid ${T.border}`, marginBottom: 8 }}>
        <div style={{ fontSize: 8.5, letterSpacing: ".18em", textTransform: "uppercase", color: T.subText, marginBottom: 2 }}>
          Rooted Connections
        </div>
        <div style={{ fontFamily: serif, fontSize: 18, color: T.headingText, letterSpacing: ".02em" }}>
          Collective
        </div>
        {/* Active child pill */}
        {isParent && activeChild && (
          <div style={{ marginTop: 10 }}>
            <ChildPill onOpen={onOpenDrawer} />
          </div>
        )}
      </div>

      {/* Main nav tabs */}
      <div style={{ flex: 1, overflowY: "auto" }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActive(t.id)} style={{
            display: "flex", alignItems: "center", gap: 10,
            width: "100%", padding: "11px 20px",
            background: active === t.id ? `${T.teal}12` : "none",
            border: "none",
            borderLeft: active === t.id ? `3px solid ${T.teal}` : "3px solid transparent",
            fontFamily: font, fontSize: 13.5,
            color: active === t.id ? T.teal : T.text,
            cursor: "pointer", textAlign: "left",
            fontWeight: active === t.id ? 600 : 400,
            transition: "all .15s",
          }}>
            <span style={{ fontSize: 16 }}>{t.icon}</span>
            {t.label}
          </button>
        ))}

        <div style={{ height: 1, background: T.border, margin: "12px 0" }} />

        {isParent && !hasConsultant && (
          <SideRow icon="🌿" label="Find a Consultant" onClick={() => onOpenFindConsultant && onOpenFindConsultant()} />
        )}

        <SideRow icon="👤" label="My Account" onClick={onOpenAccount} />
        <SideRow icon="🔔" label="Notifications" onClick={onOpenNotifications} />
        <SideRow icon="✍️" label="The Space Between" onClick={() => window.open(SUBSTACK_URL, "_blank")} />
        <SideRow icon="💬" label="Get Support" onClick={() => window.open("mailto:hello@rootedconnectionscollective.com", "_blank")} />

        <div style={{ padding: "10px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 4 }}>
          <span style={{ fontFamily: font, fontSize: 13, color: T.muted }}>Appearance</span>
          <ThemeToggle />
        </div>
      </div>

      {/* User footer */}
      <div style={{ padding: "16px 20px", borderTop: `1px solid ${T.border}`, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: "50%",
            background: `${T.teal}25`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 13, fontWeight: 700, color: T.teal, flexShrink: 0,
          }}>
            {(currentUser?.name || currentUser?.email || currentUser?.user_email || "?")[0].toUpperCase()}
          </div>
          <div style={{ overflow: "hidden", minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: T.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {currentUser?.name || "Account"}
            </div>
            <div style={{ fontSize: 10.5, color: T.muted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {currentUser?.email || currentUser?.user_email}
            </div>
          </div>
        </div>
        <button onClick={onLogout} style={{
          background: "none", border: `1px solid ${T.border}`,
          borderRadius: 10, padding: "7px 14px",
          fontFamily: font, fontSize: 12, color: T.muted,
          cursor: "pointer", width: "100%",
          display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
        }}>
          <span style={{ fontSize: 13 }}>→</span> Sign out
        </button>
      </div>
    </div>
  );
}
