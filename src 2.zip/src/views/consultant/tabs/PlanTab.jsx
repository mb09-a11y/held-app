// views/consultant/tabs/PlanTab.jsx
import { useState } from "react";
import { useT, font, serif } from "../../../core/shared.jsx";
import { usePlans } from "../data/consultantStore.js";
import InsightCard from "../shared/InsightCard.jsx";

const METHODS = [
  { id: "settled_support", label: "Settled Support",          desc: "Attuned presence, gradual withdrawal" },
  { id: "chair_method",    label: "Chair Method",             desc: "Gradual spatial removal over 7 days" },
  { id: "fading",          label: "Fading",                   desc: "Reduce prop gradually to drowsy" },
  { id: "habit_stacking",  label: "Habit Stacking",           desc: "Layer associations, remove one by one" },
  { id: "ferber",          label: "Ferber / Grad. Extinction", desc: "Graduated timed intervals" },
  { id: "kissing_game",    label: "Kissing Game",             desc: "For toddlers — returns for kisses" },
];

export default function PlanTab({ activeChild, onNavigate }) {
  const T = useT();
  const { plans, toggleItem, addConsultantNote, changeMethod } = usePlans();
  const [showMethodPicker, setShowMethodPicker] = useState(false);
  const [editingNote, setEditingNote] = useState(null); // itemId
  const [noteText, setNoteText] = useState("");

  const plan = plans[activeChild?.planId];
  if (!plan) return (
    <div style={{ padding: 40, textAlign: "center", color: T.muted, fontFamily: font }}>
      No plan assigned yet.
      <div onClick={() => onNavigate("methodMatching")} style={{ color: T.teal, marginTop: 12, cursor: "pointer", fontWeight: 600 }}>
        Assign a method →
      </div>
    </div>
  );

  const phaseStatus = (ph) => ph.items.every(i => i.done) ? "done" : ph.items.some(i => i.done) ? "current" : "upcoming";

  const handleNoteSubmit = (planId, itemId) => {
    addConsultantNote(planId, itemId, noteText);
    setEditingNote(null);
    setNoteText("");
  };

  return (
    <div>
      {/* Method + switch */}
      <div style={{ margin: "10px 18px 10px", display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ flex: 1, background: "#2D4A35", borderRadius: 12, padding: "10px 13px" }}>
          <div style={{ fontSize: 9, letterSpacing: "0.1em", textTransform: "uppercase", color: "rgba(255,255,255,0.5)", marginBottom: 2, fontFamily: font }}>
            Current method
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, color: "white", fontFamily: font }}>
            {plan.methodLabel} · Day {activeChild?.planDay}
          </div>
        </div>
        <button onClick={() => setShowMethodPicker(true)} style={{
          background: T.card, border: `1.5px solid ${T.border}`,
          borderRadius: 12, padding: "10px 13px", cursor: "pointer",
          textAlign: "center",
        }}>
          <div style={{ fontSize: 9, letterSpacing: "0.1em", textTransform: "uppercase", color: T.muted, marginBottom: 2, fontFamily: font }}>Change</div>
          <div style={{ fontSize: 14 }}>🔄</div>
        </button>
      </div>

      {/* Method picker modal */}
      {showMethodPicker && (
        <div style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)",
          zIndex: 300, display: "flex", alignItems: "flex-end",
        }} onClick={() => setShowMethodPicker(false)}>
          <div onClick={e => e.stopPropagation()} style={{
            background: T.card, borderRadius: "24px 24px 0 0",
            padding: "20px 18px 32px", width: "100%",
          }}>
            <div style={{ width: 36, height: 4, borderRadius: 2, background: T.border, margin: "0 auto 18px" }} />
            <div style={{ fontFamily: serif, fontSize: 20, color: T.headingText, marginBottom: 12 }}>Switch method</div>
            {METHODS.map(m => (
              <div key={m.id} onClick={() => { changeMethod(plan.id, m.id, m.label); setShowMethodPicker(false); }} style={{
                padding: "12px 0", borderBottom: `1px solid ${T.border}`,
                cursor: "pointer",
              }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: plan.method === m.id ? T.teal : T.text, fontFamily: font }}>{m.label}</div>
                <div style={{ fontSize: 11, color: T.muted, marginTop: 2, fontFamily: font }}>{m.desc}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Co-Pilot suggestion */}
      {activeChild?.status === "urgent" && (
        <InsightCard
          label="◎ Co-Pilot · Suggested adjustment"
          title="Cap nap at 90 min before changing method."
          body="Try schedule adjustment for 3 nights before switching method. If no improvement by Night 12, method change may be warranted."
          actions={[
            { label: "Apply", onClick: () => {} },
            { label: "Switch method instead", onClick: () => setShowMethodPicker(true) },
          ]}
        />
      )}

      {/* Nap cap */}
      <div style={{ margin: "0 18px 10px", background: T.card, borderRadius: 14, padding: "10px 14px", boxShadow: T.shadow, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 600, color: T.muted, fontFamily: font }}>Nap cap</div>
          <div style={{ fontSize: 14, color: T.text, fontFamily: font }}>{plan.napCapMinutes} min max</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {[60, 90, 120].map(m => (
            <div key={m} style={{
              padding: "4px 10px", borderRadius: 20, fontSize: 11,
              background: plan.napCapMinutes === m ? T.teal : T.bg2,
              color: plan.napCapMinutes === m ? "#fff" : T.muted,
              cursor: "pointer", fontFamily: font,
            }}>{m}m</div>
          ))}
        </div>
      </div>

      {/* Phases */}
      {plan.phases.map(ph => {
        const st = phaseStatus(ph);
        return (
          <div key={ph.id} style={{
            margin: "0 18px 10px",
            background: T.card,
            borderRadius: 18,
            padding: "14px 16px",
            boxShadow: T.shadow,
            opacity: st === "done" ? 0.72 : 1,
          }}>
            {/* Phase header */}
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <div style={{
                width: 10, height: 10, borderRadius: "50%", flexShrink: 0,
                background: st === "done" ? T.muted : st === "current" ? "#C08A3A" : T.border,
              }} />
              <div style={{ fontSize: 13, fontWeight: 600, color: T.text, flex: 1, fontFamily: font }}>{ph.label}</div>
              <div style={{
                fontSize: 10, borderRadius: 20, padding: "2px 8px", fontFamily: font,
                background: st === "done" ? T.bg2 : st === "current" ? "#FBF4E6" : T.faint,
                color: st === "done" ? T.muted : st === "current" ? "#C08A3A" : T.subText,
              }}>
                {st === "done" ? "✓ Done" : st === "current" ? "In progress" : "Upcoming"}
              </div>
            </div>

            {ph.desc && (
              <div style={{ fontSize: 11, color: T.muted, lineHeight: 1.5, marginBottom: 10, fontFamily: font }}>{ph.desc}</div>
            )}

            {/* Items */}
            {ph.items.map(item => (
              <div key={item.id}>
                <div style={{
                  display: "flex", alignItems: "flex-start", gap: 10,
                  padding: "8px 0",
                  borderBottom: `1px solid ${T.border}`,
                }}>
                  {/* Checkbox — consultant can toggle */}
                  <button onClick={() => toggleItem(plan.id, ph.id, item.id)} style={{
                    width: 20, height: 20, borderRadius: 6,
                    border: `1.5px solid ${item.done ? T.teal : T.border}`,
                    background: item.done ? T.teal : "transparent",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    cursor: "pointer", fontSize: 11, color: "#fff",
                    flexShrink: 0, marginTop: 1,
                  }}>{item.done ? "✓" : ""}</button>

                  <div style={{ flex: 1 }}>
                    <div style={{
                      fontSize: 13, color: item.done ? T.muted : T.text,
                      textDecoration: item.done ? "line-through" : "none",
                      lineHeight: 1.4, fontFamily: font,
                    }}>{item.text}</div>

                    {/* Consultant note */}
                    {plan.consultantNotes?.[item.id] && (
                      <div style={{ fontSize: 10, color: T.teal, fontStyle: "italic", marginTop: 3, fontFamily: font }}>
                        ◎ {plan.consultantNotes[item.id]}
                      </div>
                    )}
                  </div>

                  {/* Add note button */}
                  <button onClick={() => { setEditingNote(item.id); setNoteText(plan.consultantNotes?.[item.id] || ""); }} style={{
                    background: "none", border: "none", cursor: "pointer",
                    fontSize: 14, color: T.muted, padding: "2px 4px",
                  }}>✏️</button>
                </div>

                {/* Note editor */}
                {editingNote === item.id && (
                  <div style={{ padding: "8px 0 4px" }}>
                    <textarea value={noteText} onChange={e => setNoteText(e.target.value)}
                      placeholder="Add consultant note…"
                      style={{
                        width: "100%", padding: "8px 10px", borderRadius: 10,
                        border: `1.5px solid ${T.teal}`,
                        background: T.inputBg, color: T.text,
                        fontSize: 12, fontFamily: font,
                        resize: "none", height: 60, outline: "none",
                        boxSizing: "border-box",
                      }}
                    />
                    <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                      <button onClick={() => handleNoteSubmit(plan.id, item.id)} style={{
                        background: T.teal, color: "#fff", border: "none",
                        borderRadius: 10, padding: "6px 14px", fontSize: 12,
                        cursor: "pointer", fontFamily: font,
                      }}>Save</button>
                      <button onClick={() => setEditingNote(null)} style={{
                        background: "transparent", border: `1px solid ${T.border}`,
                        borderRadius: 10, padding: "6px 14px", fontSize: 12,
                        color: T.muted, cursor: "pointer", fontFamily: font,
                      }}>Cancel</button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        );
      })}

      {/* Send plan to parent */}
      <div style={{ margin: "0 18px 16px", display: "flex", gap: 7 }}>
        <button onClick={() => {}} style={{
          flex: 1, background: T.card, border: `1.5px solid ${T.border}`,
          borderRadius: 14, padding: 10, textAlign: "center", cursor: "pointer",
        }}>
          <div style={{ fontSize: 16, marginBottom: 3 }}>📤</div>
          <div style={{ fontSize: 11, color: T.muted, fontFamily: font }}>Send to parent</div>
        </button>
        <button onClick={() => {}} style={{
          flex: 1, background: T.card, border: `1.5px solid ${T.border}`,
          borderRadius: 14, padding: 10, textAlign: "center", cursor: "pointer",
        }}>
          <div style={{ fontSize: 16, marginBottom: 3 }}>🕐</div>
          <div style={{ fontSize: 11, color: T.muted, fontFamily: font }}>Version history</div>
        </button>
        <button onClick={() => setShowMethodPicker(true)} style={{
          flex: 1, background: T.card, border: `1.5px solid ${T.border}`,
          borderRadius: 14, padding: 10, textAlign: "center", cursor: "pointer",
        }}>
          <div style={{ fontSize: 16, marginBottom: 3 }}>✏️</div>
          <div style={{ fontSize: 11, color: T.muted, fontFamily: font }}>Edit method</div>
        </button>
      </div>
    </div>
  );
}
