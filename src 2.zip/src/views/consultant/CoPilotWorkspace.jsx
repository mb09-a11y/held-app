// views/consultant/CoPilotWorkspace.jsx
import { useState } from "react";
import { useT, font, serif } from "../../core/shared.jsx";
import { useFamilies } from "./data/consultantStore.js";

const SUGGESTED = [
  { q: "What's driving Benji's night wakings?", ans: "The clearest signal is nap length. On all 4 days where his nap exceeded 2h, he had 3+ night wakings. On shorter nap days, average was 1.2. Recommend capping at 90 min and monitoring for 3 nights before considering method change." },
  { q: "How should I prep for Leo tonight?",    ans: "Leo is on Day 5 — the classic regression window. Sleep latency may increase and the parent will likely panic. Draft a proactive message now normalizing tonight before it happens. Key frame: 'Day 5 is where it gets harder before it gets easier — this is expected.'" },
  { q: "Which families need attention this week?", ans: "Chen family (Benji) is urgent — night wakings up, parent NS activated. Sharma family (Leo) is watch — Day 5 regression tonight. Okafor family (Rina) is on track, no action needed." },
  { q: "Draft a check-in for Rina",            ans: "Hi Amara! Just checking in — Rina's data is looking really strong this week. Night wakings are down to 0.4 average and she's settling faster each day. You've been incredibly consistent and it's showing. How are you feeling?" },
];

export default function CoPilotWorkspace({ onNavigate }) {
  const T = useT();
  const { families } = useFamilies();

  const [input, setInput] = useState("");
  const [history, setHistory] = useState([SUGGESTED[0]]);
  const [loading, setLoading] = useState(false);

  const handleSuggested = (item) => {
    setHistory(prev => [item, ...prev]);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    const q = input.trim();
    setInput("");
    setLoading(true);
    // Simulate response — swap for real AI call later
    setTimeout(() => {
      const match = SUGGESTED.find(s => s.q.toLowerCase().includes(q.toLowerCase().split(" ")[0]));
      setHistory(prev => [{
        q,
        ans: match?.ans || `Based on your current families, here's what I can see: ${families.map(f => f.name).join(", ")} are all active. For more specific insights, check the Sleep Data tab for each child or ask me about a specific family.`,
      }, ...prev]);
      setLoading(false);
    }, 900);
  };

  return (
    <div style={{ background: T.gradientBg, flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {/* Header */}
      <div style={{ padding: "18px 18px 6px", flexShrink: 0 }}>
        <div style={{ fontSize: 9, letterSpacing: "0.16em", textTransform: "uppercase", color: T.teal, fontWeight: 600, marginBottom: 4, fontFamily: font }}>◎ Co-Pilot</div>
        <div style={{ fontFamily: serif, fontSize: 26, fontWeight: 500, color: T.headingText, marginBottom: 4 }}>Your assistant</div>
        <div style={{ fontSize: 12, color: T.muted, fontFamily: font }}>Ask anything about your families.</div>
      </div>

      {/* Suggested prompts */}
      <div style={{ padding: "8px 18px 4px", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", color: T.muted, fontWeight: 600, fontFamily: font, flexShrink: 0 }}>
        Suggested
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6, padding: "0 18px 10px", flexShrink: 0 }}>
        {SUGGESTED.map((s, i) => (
          <button key={i} onClick={() => handleSuggested(s)} style={{
            background: T.card, border: `1.5px solid ${T.border}`,
            borderRadius: 14, padding: "11px 14px",
            fontSize: 13, color: T.text, cursor: "pointer",
            display: "flex", justifyContent: "space-between", alignItems: "center",
            fontFamily: font, textAlign: "left",
          }}>
            {s.q}
            <span style={{ color: T.muted, marginLeft: 8 }}>›</span>
          </button>
        ))}
      </div>

      {/* Conversation history */}
      <div style={{ flex: 1, overflowY: "auto", padding: "0 0 4px" }}>
        {loading && (
          <div style={{ margin: "0 18px 10px", background: T.card, borderRadius: 18, padding: "14px 16px", boxShadow: T.shadow }}>
            <div style={{ fontSize: 12, color: T.muted, fontFamily: font }}>◎ Thinking…</div>
          </div>
        )}
        {history.map((item, i) => (
          <div key={i} style={{ margin: "0 18px 10px", background: T.card, borderRadius: 18, padding: "14px 16px", boxShadow: T.shadow }}>
            <div style={{ fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase", color: T.teal, fontWeight: 600, marginBottom: 6, fontFamily: font }}>◎ Co-Pilot</div>
            <div style={{ fontSize: 13, color: T.muted, fontStyle: "italic", marginBottom: 6, fontFamily: font }}>"{item.q}"</div>
            <div style={{ fontSize: 13, color: T.text, lineHeight: 1.65, fontFamily: font }}>{item.ans}</div>
            <div style={{ marginTop: 10, display: "flex", gap: 6 }}>
              <button onClick={() => {}} style={{
                background: T.teal, color: "#fff", border: "none",
                padding: "6px 13px", borderRadius: 20,
                fontSize: 11, fontWeight: 600, cursor: "pointer", fontFamily: font,
              }}>Apply</button>
              <button onClick={() => {}} style={{
                border: `1.5px solid ${T.border}`, color: T.muted,
                background: "transparent", padding: "6px 13px", borderRadius: 20,
                fontSize: 11, cursor: "pointer", fontFamily: font,
              }}>Share with family</button>
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div style={{
        margin: "0 18px 8px", background: T.card,
        border: `1.5px solid ${T.teal}44`,
        borderRadius: 18, padding: "12px 14px",
        display: "flex", gap: 8, alignItems: "center",
        flexShrink: 0,
      }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleSend()}
          placeholder="Ask about any family…"
          style={{
            flex: 1, fontSize: 13, color: T.text, fontFamily: font,
            background: "transparent", border: "none", outline: "none",
          }}
        />
        <button onClick={handleSend} style={{
          width: 32, height: 32, borderRadius: "50%",
          background: T.teal, border: "none",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 14, color: "#fff", cursor: "pointer",
        }}>↑</button>
      </div>
    </div>
  );
}
