// views/consultant/ConsultantShell.jsx
import { useState } from "react";
import { useT, font, serif } from "../../core/shared.jsx";

import ConsultantHome   from "./ConsultantHome.jsx";
import FamiliesView     from "./FamiliesView.jsx";
import FamilyDetail     from "./FamilyDetail.jsx";
import MethodMatching   from "./MethodMatching.jsx";
import RegulationLayer  from "./RegulationLayer.jsx";
import ResponseBuilder  from "./ResponseBuilder.jsx";
import CoPilotWorkspace from "./CoPilotWorkspace.jsx";
import RedFlags         from "./RedFlags.jsx";

// ── Bottom nav ────────────────────────────────────────────────────────────────
const NAV_TABS = [
  { id: "home",     icon: "🏠", label: "Home"     },
  { id: "families", icon: "👨‍👩‍👧", label: "Families" },
  { id: "plans",    icon: "📋", label: "Plans"    },
  { id: "messages", icon: "💬", label: "Messages" },
  { id: "copilot",  icon: "🧠", label: "Co-Pilot" },
];

// ── Account / hamburger drawer ─────────────────────────────────────────────────
function AccountDrawer({ isOpen, onClose, onNavigateFlag, currentUser, logout, T }) {
  if (!isOpen) return null;
  const rows = [
    { icon: "🏠", label: "Dashboard",      action: onClose },
    { icon: "👨‍👩‍👧", label: "My Families",    action: onClose },
    { icon: "📋", label: "All Plans",       action: onClose },
    { icon: "🚩", label: "Flags & Alerts",  action: () => { onClose(); onNavigateFlag(); } },
    { icon: "⚙️", label: "Account",         action: onClose },
  ];
  return (
    <div onClick={onClose} style={{
      position: "absolute", inset: 0, zIndex: 400,
      background: "rgba(0,0,0,0.55)",
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        position: "absolute", top: 0, right: 0, bottom: 0, width: 280,
        background: T.card,
        borderLeft: `1px solid ${T.border}`,
        display: "flex", flexDirection: "column",
        paddingBottom: 32,
      }}>
        {/* Hero */}
        <div style={{
          background: "linear-gradient(160deg, #2D4A35, #3A3018)",
          padding: "52px 20px 20px",
        }}>
          <div style={{
            width: 48, height: 48, borderRadius: "50%",
            background: "rgba(255,255,255,0.15)",
            border: "1.5px solid rgba(255,255,255,0.25)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 22, marginBottom: 10,
          }}>🌿</div>
          <div style={{ fontFamily: serif, fontSize: 20, color: "#fff", fontStyle: "italic" }}>
            {currentUser?.name || "Consultant"}
          </div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", marginTop: 2, fontFamily: font }}>
            {currentUser?.email || ""}
          </div>
        </div>

        {/* Rows */}
        {rows.map(row => (
          <div key={row.label} onClick={row.action} style={{
            display: "flex", alignItems: "center", gap: 12,
            padding: "14px 20px",
            borderBottom: `1px solid ${T.border}`,
            cursor: "pointer",
          }}>
            <span style={{ fontSize: 20, width: 24, textAlign: "center" }}>{row.icon}</span>
            <span style={{ fontSize: 14, color: T.text, fontFamily: font }}>{row.label}</span>
          </div>
        ))}

        <div style={{ flex: 1 }} />

        <div onClick={logout} style={{
          margin: "0 20px",
          border: `1.5px solid ${T.border}`,
          borderRadius: 14, padding: 14,
          textAlign: "center", fontSize: 13,
          color: T.muted, cursor: "pointer", fontFamily: font,
        }}>
          Sign out
        </div>
      </div>
    </div>
  );
}

// ── Main shell ─────────────────────────────────────────────────────────────────
export default function ConsultantShell({ currentUser, logout }) {
  const T = useT();

  const [activeTab,  setActiveTab]  = useState("home");
  const [navStack,   setNavStack]   = useState([]);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const navigate    = (view, params = {}) => setNavStack(prev => [...prev, { view, params }]);
  const goBack      = () => setNavStack(prev => prev.slice(0, -1));
  const goHome      = () => setNavStack([]);

  const handleTabChange = (tabId) => { setNavStack([]); setActiveTab(tabId); };

  const currentNav    = navStack[navStack.length - 1];
  const isDrilledDown = navStack.length > 0;

  // ── Drill-down views ──────────────────────────────────────────────────────
  const renderDrillDown = () => {
    if (!currentNav) return null;
    const { view, params } = currentNav;

    if (view === "family") return (
      <FamilyDetail familyId={params.familyId} onNavigate={navigate} onBack={goBack} />
    );
    if (view === "methodMatching") return (
      <MethodMatching familyId={params.familyId} childId={params.childId} onNavigate={navigate} onBack={goBack} />
    );
    if (view === "regulation") return (
      <RegulationLayer
        familyName={params.familyName}
        onRegulated={() => setNavStack(prev => [...prev.slice(0, -1), { view: "responseBuilder", params: { familyId: params.familyId } }])}
        onSkip={()      => setNavStack(prev => [...prev.slice(0, -1), { view: "responseBuilder", params: { familyId: params.familyId } }])}
      />
    );
    if (view === "responseBuilder") return (
      <ResponseBuilder familyId={params.familyId} onBack={goBack} onSent={goBack} />
    );
    if (view === "flags") return <RedFlags onNavigate={navigate} />;
    return null;
  };

  // ── Base tab views ────────────────────────────────────────────────────────
  const renderBaseTab = () => {
    if (activeTab === "home")     return <ConsultantHome   onNavigate={navigate} onOpenDrawer={() => setDrawerOpen(true)} />;
    if (activeTab === "families") return <FamiliesView     onNavigate={navigate} />;
    if (activeTab === "plans")    return <FamiliesView     onNavigate={navigate} />;
    if (activeTab === "copilot")  return <CoPilotWorkspace onNavigate={navigate} />;
    if (activeTab === "messages") return (
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 12, padding: 40, background: T.gradientBg }}>
        <div style={{ fontSize: 32 }}>💬</div>
        <div style={{ fontFamily: font, fontSize: 14, color: T.muted, textAlign: "center" }}>
          Tap a family → Respond to open the message thread.
        </div>
      </div>
    );
    return null;
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: T.bg, position: "relative" }}>

      {/* ── Back bar ── */}
      {isDrilledDown && (
        <div style={{
          display: "flex", alignItems: "center",
          padding: "12px 18px 8px",
          background: T.bg2,
          borderBottom: `1px solid ${T.border}`,
          flexShrink: 0,
        }}>
          <button onClick={goBack} style={{
            background: "none", border: "none", cursor: "pointer",
            fontSize: 13, color: T.teal, fontFamily: font, fontWeight: 500,
          }}>
            ‹ Back
          </button>
          {navStack.length > 1 && (
            <button onClick={goHome} style={{
              background: "none", border: "none", cursor: "pointer",
              fontSize: 12, color: T.muted, fontFamily: font, marginLeft: "auto",
            }}>
              Home
            </button>
          )}
        </div>
      )}

      {/* ── Content ── */}
      <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        {isDrilledDown ? renderDrillDown() : renderBaseTab()}
      </div>

      {/* ── Bottom nav ── */}
      <div style={{
        display: "flex", justifyContent: "space-around",
        padding: "10px 0 18px",
        borderTop: `1px solid ${T.border}`,
        background: T.bg2,
        flexShrink: 0,
      }}>
        {NAV_TABS.map(tab => {
          const isOn = !isDrilledDown && activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => handleTabChange(tab.id)} style={{
              display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
              background: "none", border: "none", cursor: "pointer",
              opacity: isOn ? 1 : 0.38, transition: "opacity 0.18s",
            }}>
              <span style={{ fontSize: 19 }}>{tab.icon}</span>
              <span style={{
                fontSize: 9, letterSpacing: "0.05em", textTransform: "uppercase",
                color: isOn ? T.teal : T.muted, fontWeight: 500, fontFamily: font,
              }}>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ── Drawer ── */}
      <AccountDrawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onNavigateFlag={() => navigate("flags")}
        currentUser={currentUser}
        logout={logout}
        T={T}
      />
    </div>
  );
}
