// src/modules/sos/SOSFlow.jsx
// The "I Need Help Right Now" SOS flow.
// 3 steps: Choose Feeling → Intervention (body + reframe + action) → Shift card
// Renders as a full-screen overlay on top of everything.
// No Supabase calls — this is a pure UI/content component.
// Scripts are injected inline for "My kid won't listen" (special path).

import { useState } from "react";
import { useT, useApp, font, serif } from "../../core/shared.jsx";

// ─── CONTENT ──────────────────────────────────────────────────────────────────

const FEELINGS = [
  { id: "snap",       emoji: "🤬", label: "I'm about to snap" },
  { id: "overwhelmed",emoji: "😰", label: "I feel overwhelmed" },
  { id: "wont_listen",emoji: "😵", label: "My kid won't listen" },
  { id: "failing",    emoji: "😔", label: "I feel like I'm failing" },
];

const INTERVENTIONS = {
  snap: {
    title: "I'm about to snap",
    body_title: "First — your body",
    body_steps: [
      "Drop your shoulders right now.",
      "Unclench your jaw.",
      "Press your tongue to the roof of your mouth.",
      "",
      "Exhale longer than you inhale.",
    ],
    seeing_title: "What I'm seeing",
    seeing: "Your nervous system just hit a wall. That's not weakness — that's a body doing exactly what it was built to do. This moment makes complete sense.",
    action_title: "One grounded action",
    action_steps: [
      "Sit next to your child instead of correcting.",
      "Lower your voice before you speak.",
      "Connection before direction.",
    ],
    action_cta: "Lower your voice first →",
    shift_from: "Overwhelmed",
    shift_to: "Steadier",
    shift_headline: "You caught it before it escalated.",
    shift_sub: "That was earlier than yesterday. You're learning your own system.",
    scripts: null,
  },
  overwhelmed: {
    title: "I feel overwhelmed",
    body_title: "First — your body",
    body_steps: [
      "Both feet flat on the floor.",
      "One slow exhale — longer out than in.",
      "Drop your shoulders.",
      "",
      "You don't have to fix anything right now.",
    ],
    seeing_title: "What I'm seeing",
    seeing: "Overwhelm means your system took on more than it could hold. That's not a character flaw — that's a nervous system doing its job. You're not broken. You're full.",
    action_title: "One grounded action",
    action_steps: [
      "Name one thing you can put down for the next 10 minutes.",
      "Not forever. Just right now.",
      "Lower your standards for this hour.",
    ],
    action_cta: "That's enough →",
    shift_from: "Maxed out",
    shift_to: "Back online",
    shift_headline: "You chose to resource yourself first.",
    shift_sub: "That's the whole regulation practice. You're already doing it.",
    scripts: null,
  },
  wont_listen: {
    title: "My kid won't listen",
    body_title: "First — your body",
    body_steps: [
      "Drop your shoulders.",
      "Soften your jaw.",
      "Exhale longer than you inhale.",
      "",
      "You can't reach them from this state — and that's okay. That's why you're here.",
    ],
    seeing_title: "What I'm seeing",
    seeing: "When a child 'won't listen,' their nervous system is usually too activated to process language. This isn't defiance. This is a regulated body trying to survive a dysregulated moment.",
    action_title: "One grounded action",
    action_steps: [
      "Offer connection before direction.",
      "Sit next to them instead of standing over them.",
      "Touch a shoulder before you ask anything.",
    ],
    action_cta: "Come close first →",
    shift_from: "Frustrated",
    shift_to: "Grounded",
    shift_headline: "You stayed connected instead of correcting.",
    shift_sub: "You're coming back faster now.",
    scripts: {
      title: "What to say right now",
      line: "\u201cI need your eyes. Can I have them?\u201d",
      tone: "Slow. Low. Like you have all the time in the world.",
      body: "Get physically close before you speak. Eye level if you can.",
      cta: "See more scripts for this moment \u2192",
    },
  },
  failing: {
    title: "I feel like I'm failing",
    body_title: "First — your body",
    body_steps: [
      "Hand on your chest.",
      "Feel your heartbeat.",
      "You are still here. That matters.",
      "",
      "One slow breath. In through the nose, out through the mouth.",
    ],
    seeing_title: "What I'm seeing",
    seeing: "Parents who worry they're failing are almost never the ones actually failing. The fact that you're here — asking this question — is the evidence. You care. That's the whole thing.",
    action_title: "One grounded action",
    action_steps: [
      "Name one moment this week when you showed up.",
      "It doesn't have to be big.",
      "You're building something — even when you can't see it.",
    ],
    action_cta: "I see you →",
    shift_from: "Not enough",
    shift_to: "Enough",
    shift_headline: "You showed up. Again.",
    shift_sub: "That's not nothing. That's everything.",
    scripts: null,
  },
};

// Progress without pressure — evolves with use count
const PROGRESS_STAGES = [
  { use: 1,  text: "You just supported your nervous system." },
  { use: 3,  text: "You're learning how to come back." },
  { use: 7,  text: "You're coming back faster now." },
  { use: 999, text: "This is becoming your default. \u2728" },
];

function getProgressStage(useCount) {
  for (let i = PROGRESS_STAGES.length - 1; i >= 0; i--) {
    if (useCount >= PROGRESS_STAGES[i].use) return PROGRESS_STAGES[i];
  }
  return PROGRESS_STAGES[0];
}

// ─── STEP 1: CHOOSE FEELING ───────────────────────────────────────────────────
function StepChooseFeelings({ onSelect, onClose, T }) {
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: "0 0 32px" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 32 }}>
        <button onClick={onClose} style={{
          width: 38, height: 38, borderRadius: "50%",
          background: T.faint, border: "none", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: T.muted, fontSize: 16,
        }}>←</button>
        <div style={{ fontFamily: serif, fontSize: 18, color: T.headingText, fontStyle: "italic" }}>
          I need help right now
        </div>
      </div>

      <h2 style={{ fontFamily: serif, fontSize: 28, color: T.headingText, lineHeight: 1.2, marginBottom: 8 }}>
        What&rsquo;s happening for you right now?
      </h2>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 10, marginTop: 24 }}>
        {FEELINGS.map(f => (
          <button key={f.id} onClick={() => onSelect(f.id)} style={{
            display: "flex", alignItems: "center", gap: 16,
            padding: "16px 18px", borderRadius: 16,
            border: `1px solid ${T.border}`,
            background: T.card, cursor: "pointer",
            textAlign: "left", transition: "all .15s",
          }}
            onMouseEnter={e => e.currentTarget.style.borderColor = T.teal}
            onMouseLeave={e => e.currentTarget.style.borderColor = T.border}
          >
            <span style={{ fontSize: 28, flexShrink: 0 }}>{f.emoji}</span>
            <span style={{ fontFamily: font, fontSize: 15, color: T.text, fontWeight: 500 }}>
              {f.label}
            </span>
          </button>
        ))}
      </div>

      {/* Grounding note */}
      <div style={{
        marginTop: 20, padding: "14px 16px", borderRadius: 14,
        background: T.faint,
        fontFamily: serif, fontSize: 14, fontStyle: "italic",
        color: T.muted, lineHeight: 1.55,
      }}>
        &ldquo;You don&rsquo;t have to name it perfectly. Just tap what&rsquo;s closest.&rdquo;
      </div>
    </div>
  );
}

// ─── STEP 2: INTERVENTION ─────────────────────────────────────────────────────
function StepIntervention({ feelingId, onDone, onBack, useCount, setTab, T }) {
  const data = INTERVENTIONS[feelingId];
  if (!data) return null;

  const stage = getProgressStage(useCount);

  // Previous stages (strikethrough)
  const prevStages = PROGRESS_STAGES.filter(s => s.use < stage.use && s.use <= useCount);

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", paddingBottom: 32 }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 28 }}>
        <button onClick={onBack} style={{
          width: 38, height: 38, borderRadius: "50%",
          background: T.faint, border: "none", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: T.muted, fontSize: 16,
        }}>←</button>
        <div style={{ fontFamily: serif, fontSize: 16, color: T.headingText, fontStyle: "italic" }}>
          {data.title}
        </div>
      </div>

      {/* Body card */}
      <div style={{
        borderRadius: 18, padding: "18px 20px", marginBottom: 12,
        background: T.card, border: `1px solid ${T.border}`,
      }}>
        <div style={{ fontSize: 9.5, letterSpacing: ".14em", textTransform: "uppercase", color: T.warm, fontFamily: font, fontWeight: 700, marginBottom: 14 }}>
          {data.body_title}
        </div>
        {/* Breathing icon */}
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 16 }}>
          <div style={{
            width: 72, height: 72, borderRadius: "50%",
            background: `${T.teal}20`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 32,
          }}>
            🫁
          </div>
        </div>
        {data.body_steps.map((step, i) =>
          step === "" ? (
            <div key={i} style={{ height: 10 }} />
          ) : (
            <div key={i} style={{
              fontFamily: font, fontSize: 14.5, color: T.text,
              lineHeight: 1.65, marginBottom: 2,
            }}>
              {step}
            </div>
          )
        )}
      </div>

      {/* What I'm seeing */}
      <div style={{
        borderRadius: 18, padding: "18px 20px", marginBottom: 12,
        background: T.card, border: `1px solid ${T.border}`,
      }}>
        <div style={{ fontSize: 9.5, letterSpacing: ".14em", textTransform: "uppercase", color: T.teal, fontFamily: font, fontWeight: 700, marginBottom: 10 }}>
          {data.seeing_title}
        </div>
        <p style={{ fontFamily: serif, fontSize: 16, fontStyle: "italic", color: T.text, lineHeight: 1.6, margin: 0 }}>
          &ldquo;{data.seeing}&rdquo;
        </p>
      </div>

      {/* Scripts — only for "won't listen" */}
      {data.scripts && (
        <div style={{
          borderRadius: 18, padding: "18px 20px", marginBottom: 12,
          background: `${T.teal}08`, border: `1px solid ${T.teal}25`,
        }}>
          <div style={{ fontSize: 9.5, letterSpacing: ".14em", textTransform: "uppercase", color: T.teal, fontFamily: font, fontWeight: 700, marginBottom: 12 }}>
            {data.scripts.title}
          </div>
          {/* Script line with left border */}
          <div style={{
            borderLeft: `3px solid ${T.teal}`,
            paddingLeft: 14, marginBottom: 14,
            background: T.card, borderRadius: "0 10px 10px 0",
            padding: "12px 14px",
          }}>
            <p style={{ fontFamily: serif, fontSize: 16, fontStyle: "italic", color: T.text, lineHeight: 1.55, margin: 0 }}>
              {data.scripts.line}
            </p>
          </div>
          {/* Tone + Body cues */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 14 }}>
            {[
              { icon: "🎵", label: "Tone", text: data.scripts.tone },
              { icon: "🤲", label: "Body", text: data.scripts.body },
            ].map(cue => (
              <div key={cue.label} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                <div style={{
                  width: 52, flexShrink: 0, display: "flex", flexDirection: "column",
                  alignItems: "center", gap: 2,
                  padding: "8px 4px", borderRadius: 10, background: T.faint,
                }}>
                  <span style={{ fontSize: 18 }}>{cue.icon}</span>
                  <span style={{ fontFamily: font, fontSize: 10, color: T.teal, fontWeight: 700 }}>{cue.label}</span>
                </div>
                <p style={{ fontFamily: font, fontSize: 13.5, color: T.muted, lineHeight: 1.6, margin: 0, paddingTop: 6 }}>
                  {cue.text}
                </p>
              </div>
            ))}
          </div>
          <div style={{ height: 1, background: T.border, marginBottom: 12 }} />
          <button onClick={() => setTab("library")} style={{
            background: "none", border: "none", padding: 0,
            fontFamily: font, fontSize: 13, color: T.teal,
            fontWeight: 700, cursor: "pointer",
          }}>
            {data.scripts.cta}
          </button>
        </div>
      )}

      {/* One grounded action */}
      <div style={{
        borderRadius: 18, padding: "18px 20px", marginBottom: 12,
        background: T.card, border: `1px solid ${T.border}`,
      }}>
        <div style={{ fontSize: 9.5, letterSpacing: ".14em", textTransform: "uppercase", color: T.warm, fontFamily: font, fontWeight: 700, marginBottom: 10 }}>
          {data.action_title}
        </div>
        {data.action_steps.map((step, i) => (
          <div key={i} style={{
            fontFamily: font, fontSize: 14, color: T.text,
            lineHeight: 1.65, marginBottom: 3,
          }}>
            {step}
          </div>
        ))}
        <button onClick={onDone} style={{
          marginTop: 14, padding: "10px 20px", borderRadius: 24,
          border: "none", background: T.teal, color: "#fff",
          fontFamily: font, fontSize: 13.5, fontWeight: 600, cursor: "pointer",
        }}>
          {data.action_cta}
        </button>
      </div>

      {/* Your shift right now */}
      <div style={{
        borderRadius: 18, padding: "18px 20px",
        background: `${T.teal}18`, border: `1px solid ${T.teal}30`,
      }}>
        <div style={{ fontSize: 9.5, letterSpacing: ".14em", textTransform: "uppercase", color: T.teal, fontFamily: font, fontWeight: 700, marginBottom: 12 }}>
          Your shift right now
        </div>
        {/* State transition chips */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
          <div style={{
            padding: "6px 14px", borderRadius: 20,
            background: T.faint, border: `1px solid ${T.border}`,
            fontFamily: font, fontSize: 13, color: T.muted,
          }}>
            {data.shift_from}
          </div>
          <span style={{ color: T.muted, fontSize: 16 }}>→</span>
          <div style={{
            padding: "6px 14px", borderRadius: 20,
            background: T.teal, border: `1px solid ${T.teal}`,
            fontFamily: font, fontSize: 13, fontWeight: 600, color: "white",
          }}>
            {data.shift_to}
          </div>
        </div>
        <p style={{ fontFamily: font, fontSize: 15, fontWeight: 700, color: T.headingText, lineHeight: 1.4, marginBottom: 4 }}>
          {data.shift_headline}
        </p>
        <p style={{ fontFamily: font, fontSize: 13, color: T.muted, lineHeight: 1.55, marginBottom: 16 }}>
          {data.shift_sub}
        </p>

        {/* Progress without pressure */}
        <div style={{ borderTop: `1px solid ${T.border}`, paddingTop: 14 }}>
          <div style={{ fontSize: 9.5, letterSpacing: ".14em", textTransform: "uppercase", color: T.muted, fontFamily: font, fontWeight: 700, marginBottom: 10 }}>
            Progress without pressure
          </div>
          {prevStages.map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8, marginBottom: 6 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: T.border, flexShrink: 0, marginTop: 5 }} />
              <span style={{ fontFamily: font, fontSize: 12.5, color: T.muted, textDecoration: "line-through", lineHeight: 1.5 }}>
                Use {s.use}: &ldquo;{s.text}&rdquo;
              </span>
            </div>
          ))}
          {/* Current stage — highlighted */}
          <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: T.teal, flexShrink: 0, marginTop: 5 }} />
            <span style={{ fontFamily: font, fontSize: 13, color: T.teal, fontWeight: 600, lineHeight: 1.5 }}>
              Now: &ldquo;{stage.text}&rdquo;
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN SOS FLOW ────────────────────────────────────────────────────────────
export function SOSFlow({ onClose, setTab }) {
  const T = useT();
  const [step, setStep] = useState("choose"); // "choose" | "intervention"
  const [feelingId, setFeelingId] = useState(null);

  // Track use count in sessionStorage for progress stages
  const sosUseCount = (() => {
    try {
      const n = parseInt(sessionStorage.getItem("held_sos_count") || "0");
      return isNaN(n) ? 0 : n;
    } catch { return 0; }
  })();

  function handleSelectFeeling(id) {
    setFeelingId(id);
    setStep("intervention");
    try {
      sessionStorage.setItem("held_sos_count", String(sosUseCount + 1));
    } catch {}
  }

  function handleDone() {
    onClose();
  }

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 300,
      background: T.bg,
      display: "flex", flexDirection: "column",
      overflowY: "auto",
      padding: "env(safe-area-inset-top, 20px) 20px 0",
    }}>
      {step === "choose" && (
        <StepChooseFeelings
          onSelect={handleSelectFeeling}
          onClose={onClose}
          T={T}
        />
      )}
      {step === "intervention" && feelingId && (
        <StepIntervention
          feelingId={feelingId}
          onDone={handleDone}
          onBack={() => setStep("choose")}
          useCount={sosUseCount}
          setTab={setTab}
          T={T}
        />
      )}
    </div>
  );
}
